var MAPJS = MAPJS || {};
