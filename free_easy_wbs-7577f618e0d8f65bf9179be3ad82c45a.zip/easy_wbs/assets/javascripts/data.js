window.ysy = window.ysy || {};
ysy.data = ysy.data || {};
$.extend(ysy.data, {
  trackers: [],
  priorities: [],
  statuses: [],
  users: []
});