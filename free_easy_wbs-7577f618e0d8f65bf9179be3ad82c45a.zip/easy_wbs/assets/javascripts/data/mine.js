function test_tree() {
  return {
    "title": "Mindmup",
    "id": 1,
    "formatVersion": 1, "ideas": {
      "2": {
        "title": "flexible layout",
        "id": 10,
        "ideas": {
          "1": {
            "title": "easy to balance map",
            "id": 103,
            "attr": {
              "style": {
                "background": "#99cc00"
              }
            },
            "ideas": {
              "1": {
                "title": "as seen here!",
                "id": 104,
                "attr": {
                  "style": {
                    "background": "#99cc00"
                  }
                }
              }
            }
          },
          "2": {
            "title": "with sensible adjustment of surrounding branches",
            "id": 140,
            "attr": {
              "style": {
                "background": "#99cc00"
              }
            }
          }
        }
      },
      "3":{
        "title":"numbers",
        "id":126,
        "ideas": {
          "1": {
            "title": "1 selects 1st-level nodes",
            "id": 143,
            "attr": {
              "style": {
                "background": "#E0E060"
              }
            }
          },
          "2": {
            "title": "2 selects 2nd-level nodes",
            "id": 144,
            "attr": {
              "style": {
                "background": "#E0E060"
              }
            }
          },
          "3": {
            "title": "etc. ......",
            "id": 145,
            "attr": {
              "style": {
                "background": "#E0E060"
              }
            }
          }
        },
        "attr": {
          "position": [
            803.9179687500005,
            -59.18359375000034,
            61
          ],
          "style": {
            "background": "#E0E060"
          }
        }
      }
    }
  }
}
